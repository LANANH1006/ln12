package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

/** Bảng nhập: tọa độ X Z muốn dò, Y xây, kích thước khu, xa hang bao nhiêu chunk... rồi bấm TÌM. */
public class BaseFinderScreen extends Screen {
    final Screen parent;
    TextFieldWidget fx, fz, fy, fsx, fsz, ffar, ftol;
    ButtonWidget bSchem, bCaves;

    public BaseFinderScreen(Screen parent) { super(Text.literal("Tìm chỗ xây base")); this.parent = parent; }

    TextFieldWidget field(int x, int y, int w, String val) {
        TextFieldWidget f = new TextFieldWidget(textRenderer, x, y, w, 18, Text.literal(""));
        f.setMaxLength(8); f.setText(val);
        addDrawableChild(f);
        return f;
    }

    @Override protected void init() {
        Config c = Config.I;
        int cx = width / 2, x = cx - 20, y = Math.max(24, height / 2 - 100);
        fx = field(x, y, 100, "" + c.bfX);
        fz = field(x, y + 22, 100, "" + c.bfZ);
        fy = field(x, y + 44, 100, "" + c.bfY);
        fsx = field(x, y + 66, 46, "" + c.bfSX);
        fsz = field(x + 54, y + 66, 46, "" + c.bfSZ);
        ffar = field(x, y + 88, 100, "" + c.bfFar);
        ftol = field(x, y + 110, 100, "" + c.bfTol);
        int by = y + 138;
        addDrawableChild(ButtonWidget.builder(Text.literal("Lấy tọa độ của tôi"), b -> {
            var p = MinecraftClient.getInstance().player;
            if (p != null) { fx.setText("" + p.getBlockX()); fz.setText("" + p.getBlockZ()); fy.setText("" + (p.getBlockY() - 5)); }
        }).dimensions(cx - 110, by, 220, 20).build());
        bSchem = addDrawableChild(ButtonWidget.builder(label("Theo schematic", c.bfSchem), b -> { c.bfSchem = !c.bfSchem; b.setMessage(label("Theo schematic", c.bfSchem)); })
                .dimensions(cx - 110, by + 24, 108, 20).build());
        bCaves = addDrawableChild(ButtonWidget.builder(label("Hiện chunk hang", c.bfCaves), b -> { c.bfCaves = !c.bfCaves; b.setMessage(label("Hiện chunk hang", c.bfCaves)); })
                .dimensions(cx + 2, by + 24, 108, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("§aTÌM"), b -> { save(); BaseFinder.start(MinecraftClient.getInstance()); })
                .dimensions(cx - 110, by + 48, 108, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("§cXÓA"), b -> BaseFinder.clear()).dimensions(cx + 2, by + 48, 108, 20).build());
    }

    static Text label(String s, boolean on) { return Text.literal(s + ": " + (on ? "§aBẬT" : "§cTẮT")); }

    static int num(TextFieldWidget f, int def) { try { return Integer.parseInt(f.getText().trim()); } catch (Exception e) { return def; } }

    void save() {
        Config c = Config.I;
        c.bfX = num(fx, c.bfX); c.bfZ = num(fz, c.bfZ); c.bfY = Math.max(-60, Math.min(300, num(fy, c.bfY)));
        c.bfSX = Math.max(8, Math.min(128, num(fsx, c.bfSX))); c.bfSZ = Math.max(8, Math.min(128, num(fsz, c.bfSZ)));
        c.bfFar = Math.max(0, Math.min(10, num(ffar, c.bfFar))); c.bfTol = Math.max(0, num(ftol, c.bfTol));
        Config.save();
    }

    @Override public void render(DrawContext ctx, int mx, int my, float d) {
        ctx.fill(0, 0, width, height, MenuBg.a(0xE00B0B14));
        super.render(ctx, mx, my, d);
        int cx = width / 2, x = cx - 110, y = Math.max(24, height / 2 - 100);
        ctx.drawCenteredTextWithShadow(textRenderer, "TÌM CHỖ XÂY BASE KHÔNG CÓ HANG", cx, y - 16, 0xFFFF69B4);
        String[] lb = {"X tâm", "Z tâm", "Y xây", "Rộng X / Z", "Xa hang (chunk)", "Dung sai hang"};
        for (int i = 0; i < lb.length; i++) ctx.drawTextWithShadow(textRenderer, lb[i], x, y + 5 + i * 22, 0xFFDDDDEE);
        String st = BaseFinder.status;
        if (!st.isEmpty()) ctx.drawCenteredTextWithShadow(textRenderer, st, cx, y + 138 + 76, 0xFFFFFFFF);
        ctx.drawCenteredTextWithShadow(textRenderer, "§8Chỉ quét được chunk đã tải: đứng gần tọa độ cần dò", cx, y + 138 + 90, 0xFF888899);
    }

    @Override public void removed() { save(); }
    @Override public void close() { MinecraftClient.getInstance().setScreen(parent); }
}

package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.util.InputUtil;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

/** Âm bàn phím cơ (bản 2.18): Creamy / Thock / Clicky / Vanilla. Mỗi phím gõ -> 1 tiếng, phím to (Space/Enter/Backspace) tiếng riêng. */
public class KeySound {
    static final boolean[] down = new boolean[350];
    static final boolean[] mdown = new boolean[3];
    static final String[] PACKS = {"creamy", "thock", "clicky"};
    public static final String[] PACK_NAMES = {"Creamy", "Thock", "Clicky", "Vanilla"};

    static SoundEvent ev(String n) { return SoundEvent.of(Identifier.of("safeanchor", n)); }

    static void play(MinecraftClient mc, int key, boolean release) {
        Config c = Config.I;
        float vol = Math.max(0f, Math.min(1f, c.keySoundVol / 100f));
        float pitch = (float) (c.keySoundPitch / 100.0) * (0.97f + (float) Math.random() * 0.06f);
        pitch = Math.max(0.5f, Math.min(2.0f, pitch));
        if (c.keySoundType >= 3) {                               // Vanilla: tiếng click nút của game
            mc.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK, release ? pitch * 1.3f : pitch));
            return;
        }
        String pack = PACKS[Math.max(0, c.keySoundType)];
        boolean big = key == GLFW.GLFW_KEY_SPACE || key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_BACKSPACE;
        String kind = release ? "up" : big ? "space" : "down";
        mc.getSoundManager().play(PositionedSoundInstance.master(ev("key_" + pack + "_" + kind), pitch, vol));
    }

    public static void tick(MinecraftClient mc) {
        Config c = Config.I;
        if (!c.keySound || !c.enabled) return;
        long h = mc.getWindow().getHandle();
        for (int k = 32; k < 350; k++) {
            boolean d = InputUtil.isKeyPressed(h, k);
            if (d != down[k]) {
                down[k] = d;
                if (d) play(mc, k, false); else if (c.keySoundRelease) play(mc, k, true);
            }
        }
        for (int b = 0; b < 3; b++) {
            boolean d = GLFW.glfwGetMouseButton(h, b) == GLFW.GLFW_PRESS;
            if (d != mdown[b]) {
                mdown[b] = d;
                if (d) play(mc, 0, false); else if (c.keySoundRelease) play(mc, 0, true);
            }
        }
    }
}

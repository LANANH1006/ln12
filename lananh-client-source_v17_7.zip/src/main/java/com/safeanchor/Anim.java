package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/** Animation tiêu đề menu: từng chữ "CLIENTS BY LAN ANH" (hồng) trượt lên và hiện dần. */
public class Anim {
    public static long start = 0;           // đặt = System.currentTimeMillis() khi mở menu
    static final String T = "CLIENTS BY LAN ANH";

    public static void title(DrawContext ctx, int cx, int y) {
        MinecraftClient mc = MinecraftClient.getInstance();
        float sc = 1.5f;
        long el = System.currentTimeMillis() - start;
        int n = T.length();
        int[] w = new int[n];
        float total = 0;
        for (int i = 0; i < n; i++) { w[i] = mc.textRenderer.getWidth(String.valueOf(T.charAt(i))) + 1; total += w[i] * sc; }
        float x = cx - total / 2f;
        for (int i = 0; i < n; i++) {
            float t = (el - i * 55L) / 320f;
            if (t > 0) {
                t = Math.min(1f, t);
                float ease = 1f - (1f - t) * (1f - t) * (1f - t);
                int a = Math.max(8, (int) (255 * ease));
                float dy = (1f - ease) * 12f;
                int rgb = Config.I.chroma ? Util.chroma(i * 0.04) : 0xFF69B4;
                var ms = ctx.getMatrices();
                ms.push(); ms.translate(x, y - dy, 0); ms.scale(sc, sc, 1f);
                ctx.drawText(mc.textRenderer, Text.literal(String.valueOf(T.charAt(i))).formatted(Formatting.BOLD), 0, 0, (a << 24) | rgb, true);
                ms.pop();
            }
            x += w[i] * sc;
        }
    }
}

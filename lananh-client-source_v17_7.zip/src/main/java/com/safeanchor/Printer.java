package com.safeanchor;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.enums.ComparatorMode;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.*;
import net.minecraft.registry.Registries;
import net.minecraft.state.property.Properties;
import net.minecraft.state.property.Property;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.stream.Stream;

/** Xây theo schematic (.litematic). Tự chỉnh hướng đặt (gửi packet xoay đầu thật nên chạy được server vanilla). */
public class Printer {
    public static Map<Long, BlockState> blocks = new HashMap<>();
    public static String loadedName = null;
    public static BlockPos origin;
    static int timer;

    public static Path dir() {
        Path d = FabricLoader.getInstance().getGameDir().resolve("schematics");
        try { Files.createDirectories(d); } catch (Exception ignored) {}
        return d;
    }
    public static List<String> list() {
        List<String> r = new ArrayList<>();
        try (Stream<Path> s = Files.list(dir())) { s.filter(f -> f.toString().endsWith(".litematic")).forEach(f -> r.add(f.getFileName().toString())); }
        catch (Exception ignored) {}
        Collections.sort(r); return r;
    }

    // ---------- đọc .litematic ----------
    public static void load(String name) throws Exception {
        Map<Long, BlockState> out = new HashMap<>();
        try (InputStream in = Files.newInputStream(dir().resolve(name))) {
            NbtCompound root = NbtIo.readCompressed(in, NbtSizeTracker.ofUnlimitedBytes());
            NbtCompound regions = root.getCompound("Regions");
            for (String rn : regions.getKeys()) {
                NbtCompound r = regions.getCompound(rn);
                NbtCompound pos = r.getCompound("Position"), size = r.getCompound("Size");
                int px = pos.getInt("x"), py = pos.getInt("y"), pz = pos.getInt("z");
                int sx = size.getInt("x"), sy = size.getInt("y"), sz = size.getInt("z");
                int ax = Math.abs(sx), ay = Math.abs(sy), az = Math.abs(sz);
                int bx = sx < 0 ? px + sx + 1 : px, by = sy < 0 ? py + sy + 1 : py, bz = sz < 0 ? pz + sz + 1 : pz;

                NbtList pal = r.getList("BlockStatePalette", NbtElement.COMPOUND_TYPE);
                BlockState[] states = new BlockState[pal.size()];
                for (int i = 0; i < pal.size(); i++) states[i] = parseState(pal.getCompound(i));
                long[] data = r.getLongArray("BlockStates");
                int bits = Math.max(2, 32 - Integer.numberOfLeadingZeros(Math.max(1, pal.size() - 1)));
                long mask = (1L << bits) - 1;
                for (int y = 0; y < ay; y++) for (int z = 0; z < az; z++) for (int x = 0; x < ax; x++) {
                    long idx = ((long) y * az + z) * ax + x;
                    long bit = idx * bits; int w = (int) (bit >>> 6); int off = (int) (bit & 63);
                    long v;
                    if (off + bits <= 64) v = (data[w] >>> off) & mask;
                    else v = ((data[w] >>> off) | (data[w + 1] << (64 - off))) & mask;
                    if (v >= states.length) continue;
                    BlockState s = states[(int) v];
                    if (s.isAir() || s.isOf(Blocks.STRUCTURE_VOID)) continue;
                    out.put(new BlockPos(bx + x, by + y, bz + z).asLong(), s);
                }
            }
        }
        blocks = out; loadedName = name;
        var p = MinecraftClient.getInstance().player;
        origin = p != null ? p.getBlockPos() : BlockPos.ORIGIN;
    }

    public static void setOriginHere() {
        var p = MinecraftClient.getInstance().player;
        if (p != null) origin = p.getBlockPos();
    }

    public static void toggle(MinecraftClient mc) {
        Config.I.printerOn = !Config.I.printerOn; Config.save();
        Util.msg("Printer: " + (Config.I.printerOn ? "§aBẬT" : "§cTẮT"));
    }

    // ---------- tick ----------
    public static void tick(MinecraftClient mc) {
        Config c = Config.I; var p = mc.player; var w = mc.world;
        if (!c.printerOn || !c.enabled || blocks.isEmpty() || origin == null || p == null || w == null || mc.interactionManager == null) { releaseWalk(mc); return; }
        if (mc.currentScreen != null) return;
        if (--timer > 0) return;
        timer = Math.max(1, c.printerDelay);

        int ri = (int) Math.ceil(c.printerRange);
        BlockPos pc = p.getBlockPos();
        List<BlockPos> cand = new ArrayList<>();
        for (int dx = -ri; dx <= ri; dx++) for (int dy = -ri; dy <= ri; dy++) for (int dz = -ri; dz <= ri; dz++) {
            BlockPos q = pc.add(dx, dy, dz);
            if (blocks.containsKey(q.subtract(origin).asLong())) cand.add(q);
        }
        // ----- hàng (layer): chỉ xây hàng thấp nhất / cao nhất còn thiếu, xong tự chuyển hàng mới -----
        if (c.printerLayerMode != 0) {
            if (--layerTimer <= 0) { layerTimer = 20; computeLayer(mc); }
            if (layerY != Integer.MIN_VALUE) cand.removeIf(q -> q.getY() != layerY);
        }
        if (c.printerLook) {      // chỉ đặt block theo hướng đang nhìn (trong nón 45 độ)
            Vec3d look = p.getRotationVec(1f);
            cand.removeIf(q -> look.dotProduct(Vec3d.ofCenter(q).subtract(p.getEyePos()).normalize()) < 0.7);
            cand.sort(Comparator.comparingDouble(q -> -look.dotProduct(Vec3d.ofCenter(q).subtract(p.getEyePos()).normalize())));
        } else {
            cand.sort(Comparator.<BlockPos>comparingInt(BlockPos::getY).thenComparingDouble(q -> Vec3d.ofCenter(q).squaredDistanceTo(p.getPos())));
        }
        if (c.printerWalk && cand.isEmpty() && layerTarget != null) walkTo(mc, layerTarget); else releaseWalk(mc);

        int done = 0;
        for (BlockPos q : cand) {
            if (Vec3d.ofCenter(q).distanceTo(p.getEyePos()) > c.printerRange + 0.9) continue;
            BlockState want = blocks.get(q.subtract(origin).asLong());
            BlockState cur = w.getBlockState(q);
            if (cur.isOf(want.getBlock())) {
                if (c.printerClicks && fixClicks(mc, q, cur, want)) done++;
            } else if (cur.isReplaceable()) {
                if (tryPlace(mc, q, want)) done++;
            }
            if (done >= c.printerPerTick) break;
        }
    }

    static boolean fixClicks(MinecraftClient mc, BlockPos pos, BlockState cur, BlockState want) {
        int n = 0;
        if (cur.isOf(Blocks.NOTE_BLOCK)) n = (want.get(Properties.NOTE) - cur.get(Properties.NOTE) + 25) % 25;
        else if (cur.isOf(Blocks.REPEATER)) n = (want.get(Properties.DELAY) - cur.get(Properties.DELAY) + 4) % 4;
        else if (cur.isOf(Blocks.COMPARATOR)) n = want.get(Properties.COMPARATOR_MODE) != cur.get(Properties.COMPARATOR_MODE) ? 1 : 0;
        if (n == 0) return false;
        Vec3d hit = Vec3d.ofCenter(pos).add(0, 0.5, 0);
        ActionResult r = Util.interact(mc.player, Hand.MAIN_HAND, new BlockHitResult(hit, Direction.UP, pos, false));
        if (r.isAccepted()) mc.player.swingHand(Hand.MAIN_HAND);
        return true;
    }

    static final Property<?>[] KEYPROPS = {Properties.FACING, Properties.HORIZONTAL_FACING, Properties.HOPPER_FACING,
            Properties.AXIS, Properties.BLOCK_HALF, Properties.SLAB_TYPE, Properties.BLOCK_FACE};

    static boolean sameForPlacement(BlockState a, BlockState b) {
        if (a.getBlock() != b.getBlock()) return false;
        for (Property<?> pr : KEYPROPS) {
            if (b.contains(pr) && a.contains(pr) && !a.get(pr).equals(b.get(pr))) return false;
        }
        return true;
    }

    static boolean tryPlace(MinecraftClient mc, BlockPos pos, BlockState want) {
        Config c = Config.I; var p = mc.player; var w = mc.world;
        Item item = want.getBlock().asItem();
        if (item == Items.AIR) return false;
        boolean haveItem = Util.has(s -> s.isOf(item));
        if (!haveItem && p.isCreative()) {
            int slot = Math.max(0, Math.min(8, c.spareSlot - 1));
            mc.interactionManager.clickCreativeStack(new ItemStack(item), 36 + slot);
            haveItem = true;
        }
        if (!haveItem) return false;

        float oy = p.getYaw(), op = p.getPitch();
        float[] yaws = c.printerFixRotate ? new float[]{oy, 0, 90, 180, 270} : new float[]{oy};
        float[] pitches = c.printerFixRotate ? new float[]{op, 0, -90, 90} : new float[]{op};
        float[] fracs = {0.5f, 0.25f, 0.75f};

        for (Direction d : Direction.values()) {
            BlockPos nb = pos.offset(d);
            BlockState ns = w.getBlockState(nb);
            if (ns.isAir() || ns.isReplaceable() || !ns.getFluidState().isEmpty()) continue;
            Direction side = d.getOpposite();
            for (float fr : fracs) {
                double hx = nb.getX() + 0.5 + side.getOffsetX() * 0.5, hz = nb.getZ() + 0.5 + side.getOffsetZ() * 0.5;
                double hy = side.getAxis().isHorizontal() ? nb.getY() + fr : nb.getY() + 0.5 + side.getOffsetY() * 0.5;
                Vec3d hit = new Vec3d(hx, hy, hz);
                if (p.getEyePos().distanceTo(hit) > c.printerRange + 0.9) continue;
                for (float yw : yaws) for (float pt : pitches) {
                    BlockHitResult bhr = new BlockHitResult(hit, side, nb, false);
                    p.setYaw(yw); p.setPitch(pt);
                    BlockState res = null;
                    try {
                        ItemPlacementContext ctx = new ItemPlacementContext(p, Hand.MAIN_HAND, new ItemStack(item), bhr);
                        if (ctx.canPlace()) res = want.getBlock().getPlacementState(ctx);
                    } catch (Exception ignored) {}
                    p.setYaw(oy); p.setPitch(op);
                    if (res == null || !sameForPlacement(res, want)) continue;

                    // thực sự đặt: xoay thật bằng packet -> đặt -> trả góc nhìn lại
                    if (!Util.selectItem(s -> s.isOf(item))) return false;
                    boolean rot = yw != oy || pt != op;
                    if (rot) Util.sendLook(yw, pt);
                    if (c.printerSneak) Util.sendSneak(true);
                    ActionResult r = Util.interact(p, Hand.MAIN_HAND, bhr);
                    if (r.isAccepted()) p.swingHand(Hand.MAIN_HAND);
                    if (c.printerSneak) Util.sendSneak(false);
                    if (rot) Util.sendLook(oy, op);
                    return r.isAccepted();
                }
            }
        }
        return false;
    }

    // ---------- layer / đi bộ ----------
    static int layerY = Integer.MIN_VALUE, layerTimer;
    static BlockPos layerTarget;
    static boolean walking;

    static void computeLayer(MinecraftClient mc) {
        Config c = Config.I; var p = mc.player; var w = mc.world;
        int ly = c.printerLayerMode == 2 ? Integer.MIN_VALUE : Integer.MAX_VALUE;
        for (var e : blocks.entrySet()) {
            BlockPos q = BlockPos.fromLong(e.getKey()).add(origin);
            if (!w.getChunkManager().isChunkLoaded(q.getX() >> 4, q.getZ() >> 4)) continue;
            if (!w.getBlockState(q).isReplaceable()) continue;
            if (c.printerLayerMode == 2) ly = Math.max(ly, q.getY()); else ly = Math.min(ly, q.getY());
        }
        if (ly == Integer.MAX_VALUE || ly == Integer.MIN_VALUE) { layerY = Integer.MIN_VALUE; layerTarget = null; return; }
        layerY = ly;
        BlockPos best = null; double bd = 1e18;
        for (var e : blocks.entrySet()) {
            BlockPos q = BlockPos.fromLong(e.getKey()).add(origin);
            if (q.getY() != ly || !w.getChunkManager().isChunkLoaded(q.getX() >> 4, q.getZ() >> 4) || !w.getBlockState(q).isReplaceable()) continue;
            double d = q.getSquaredDistance(p.getPos());
            if (d < bd) { bd = d; best = q; }
        }
        layerTarget = best;
    }

    static void walkTo(MinecraftClient mc, BlockPos target) {
        var p = mc.player;
        Vec3d t = Vec3d.ofBottomCenter(target);
        double h = Math.hypot(p.getX() - t.x, p.getZ() - t.z);
        if (h < 2.5) { releaseWalk(mc); return; }
        Util.aim(p, new Vec3d(t.x, p.getEyeY(), t.z));
        mc.options.forwardKey.setPressed(true); walking = true;
        if (p.horizontalCollision && p.isOnGround()) p.jump();
    }
    static void releaseWalk(MinecraftClient mc) { if (walking) { mc.options.forwardKey.setPressed(false); walking = false; } }

    static BlockState parseState(NbtCompound c) {
        Block b = Registries.BLOCK.get(Identifier.of(c.getString("Name")));
        BlockState s = b.getDefaultState();
        if (c.contains("Properties")) {
            NbtCompound pr = c.getCompound("Properties");
            for (String k : pr.getKeys()) {
                Property<?> p = b.getStateManager().getProperty(k);
                if (p != null) s = withProp(s, p, pr.getString(k));
            }
        }
        return s;
    }

    static <T extends Comparable<T>> BlockState withProp(BlockState s, Property<T> p, String v) {
        return p.parse(v).map(x -> s.with(p, x)).orElse(s);
    }
}
